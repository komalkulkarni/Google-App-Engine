<?php
	session_start();
	if(!isset($_SESSION['agentAuth']))
		header('Location: login.php');
		
	require_once '../settings/config.php';
?>