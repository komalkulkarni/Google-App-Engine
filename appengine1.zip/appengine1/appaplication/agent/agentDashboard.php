<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->

<?php 
	require_once 'includes/agentHeader.php';
?>


    <div class="main">
      <div class="container">
        <ul class="breadcrumb">
            <li><a href="agentDashboard.php">Home</a></li>
            <li class="active">Dashboard</li>
        </ul>
        <!-- BEGIN SIDEBAR & CONTENT -->
        <div class="row margin-bottom-40">
         
         
         <?php 
			require_once 'includes/agentLeftMenu.php';
		?>

          <!-- BEGIN CONTENT -->
          <div class="col-md-9 col-sm-9">
            <h3>Welcome User!</h3>
            <div class="content-form-page">
              <div class="row">
               
               
              </div>
            </div>
          </div>
          <!-- END CONTENT -->
        </div>
        <!-- END SIDEBAR & CONTENT -->
      </div>
    </div>

	<?php 
		require_once 'includes/agentFooter.php';
	?>

    <script type="text/javascript">
        jQuery(document).ready(function() {
            Layout.init();
        });
    </script>
    <!-- END PAGE LEVEL JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>