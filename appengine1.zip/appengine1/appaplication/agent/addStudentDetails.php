<?php 
	require_once 'agentAuthorized.php';
	require_once '../functions/commonFunctions.php';
	
	require_once '../classes/StudentAgentModel.php';
	DatastoreService::setInstance(new DatastoreService($google_api_config));
		
	$msg="";
	
	if (array_key_exists_r('coursename|studentname|certificatedate|studentid|submit', $_POST)) 
	{
			
			$courseid = sha1(htmlspecialchars($_POST['coursename']));
			
			$coursename = htmlspecialchars($_POST['coursename']);
			
			$studentname = htmlspecialchars($_POST['studentname']);
			$certificatedate = htmlspecialchars($_POST['certificatedate']);
			$studentid = htmlspecialchars($_POST['studentid']);
			$certificateactivation = 'N';
			$agentid = $_SESSION['agentAuth'];
			$certificateadddate = '';

			$studentagent_model = new StudentAgentModel($courseid,$coursename,$studentname,$certificatedate,$studentid,$certificateactivation,$agentid,$certificateadddate);

			$studentagent_model->put();

			$msg="Student Added Successfully.";
			
    }
	
?>

<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->

<?php 
	require_once 'includes/agentHeader.php';
?>

<div class="main">
      <div class="container">
        <ul class="breadcrumb">
            <li><a href="agentDashboard.php">Home</a></li>
            <li class="active">Dashboard</li>
        </ul>
        <!-- BEGIN SIDEBAR & CONTENT -->
        <div class="row margin-bottom-40">
         
         
         <?php 
			require_once 'includes/agentLeftMenu.php';
		?>

          <!-- BEGIN CONTENT -->
          <div class="col-md-9 col-sm-9">
            <div class="content-form-page">
              <!-- BEGIN PAGE CONTENT-->
			<div class="row">
				<div class="col-md-6 ">
					<!-- BEGIN SAMPLE FORM PORTLET-->
					<div class="portlet box blue">
						<div class="portlet-title">
							<div class="caption">
								<i class="fa fa-gift"></i> Add Student Certificate Details
							</div>
							<div class="tools">
								<a href="" class="collapse">
								</a>
								<a href="#portlet-config" data-toggle="modal" class="config">
								</a>
								<a href="" class="reload">
								</a>
								<a href="" class="remove">
								</a>
							</div>
						</div>
						<?php 
							if($msg!='')
							{ 
						?>
						<div class="alert alert-danger display-hide" style="display: block;">
							<button data-close="alert" class="close"></button>
							<?php print $msg;?>
						</div>
						<?php
							}
						?>
						<div class="portlet-body form">
							<form role="form" action="" method="POST">
								<?php 
									require_once '../classes/CourseModel.php';
									$objArr=array();
									$course_model_fetched = CourseModel::all();
									$corseNmId = new CourseModel();
									foreach($course_model_fetched as $key => $val)
									{
										$objArr[]=$corseNmId->getCourseEmail($val);
									}
							
								?>
								<div class="form-body">
									<div class="form-group">
										<label>Course Name</label>
										<div class="input-icon">
											<select name="coursename" id="coursename" class="form-control" required />
												<option value=''>Select Course Name</option>
												<?php
													foreach($objArr as $val)
													{
														print "<option value='".$val['coursename']."'>".$val['coursename']."</option>";
													}
												?>
											</select>
										</div>
									</div>
									<div class="form-group">
										<label>Student Name</label>
										<div class="input-icon">
											<input id="studentname" type="text" name="studentname" value="" placeholder="Enter Student Name" class="form-control" required />
										</div>
									</div>
									<div class="form-group">
										<label>Certificate Date</label>
										<div class="input-icon">
											<input type="text" id="certificatedate" name="certificatedate" value="" class="form-control" placeholder="Date in yy-mm-dd" required>
										</div>
									</div>
									<div class="form-group">
										<label>Student Id</label>
										<div class="input-icon">
											<input id="studentid" type="text" name="studentid" value="" placeholder="Enter Student Id" class="form-control" required />
										</div>
									</div>
								</div>
								<div class="form-actions">
									<button type="submit" name="submit" class="btn blue">Add Student</button>
									<button type="button" class="btn default">Cancel</button>
								</div>
							</form>
						</div>
					</div>
					<!-- END SAMPLE FORM PORTLET-->
					
					
				</div>
				
			</div>
			<!-- END PAGE CONTENT-->
            </div>
          </div>
          <!-- END CONTENT -->
        </div>
        <!-- END SIDEBAR & CONTENT -->
      </div>
    </div>

	<?php 
		require_once 'includes/agentFooter.php';
	?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.0/themes/smoothness/jquery-ui.css">
		<script src="//code.jquery.com/jquery-1.10.2.js"></script>
		<script src="//code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
<script src="../assets/frontend/layout/scripts/layout.js" type="text/javascript"></script>
    <script type="text/javascript">
        jQuery(document).ready(function() {
            Layout.init();
            Layout.initUniform();
            Layout.initTwitter();
        });
    </script>
	
	<script>
			$(function() {
			$( "#certificatedate" ).datepicker({
			dateFormat: 'yy-mm-dd',
			});
			});
		</script>
<!-- END JAVASCRIPTS -->

	
</html>

