<?php
	if(basename($_SERVER['SCRIPT_NAME'])=='agentDashboard.php')
		$classname1='list-group-item clearfix active';
	else
		$classname1='list-group-item';
		
	if(basename($_SERVER['SCRIPT_NAME'])=='manageStudentDetails.php')
		$classname2='list-group-item clearfix active';
	else
		$classname2='list-group-item';
		
	if(basename($_SERVER['SCRIPT_NAME'])=='addStudentDetails.php')
		$classname3='list-group-item clearfix active';
	else
		$classname3='list-group-item';
		
	
?>


<!-- BEGIN SIDEBAR -->
	<div class="sidebar col-md-3 col-sm-3">
		<ul class="list-group margin-bottom-25 sidebar-menu">
			<li class="<?php print $classname1;?>"><a href="agentDashboard.php">Homepage</a></li>
			<li class="<?php print $classname2;?>"><a href="manageStudentDetails.php">Manage Student</a></li>
			<li class="<?php print $classname3;?>"><a href="addStudentDetails.php">Add Student Details</a></li>
			<li class="list-group-item clearfix"><a href="logout.php">Logout</a></li>
		</ul>
	</div>
<!-- END SIDEBAR -->