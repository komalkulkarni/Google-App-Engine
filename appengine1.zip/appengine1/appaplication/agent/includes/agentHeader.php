<?php
	if(basename($_SERVER['SCRIPT_NAME'])=='agentDashboard.php')
		$classname1='dropdown active';
	else
		$classname1='dropdown';
		
	if(basename($_SERVER['SCRIPT_NAME'])=='manageStudentDetails.php')
		$classname2='dropdown active';
	else
		$classname2='dropdown';
		
	if(basename($_SERVER['SCRIPT_NAME'])=='addStudentDetails.php')
		$classname3='dropdown active';
	else
		$classname3='dropdown';
		
	
?>
<!-- Head BEGIN -->
<head>
  <meta charset="utf-8">
 <title>Certificate Validate Portal | Agent Dashboard</title>

  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

  <meta content="Metronic Shop UI description" name="description">
  <meta content="Metronic Shop UI keywords" name="keywords">
  <meta content="keenthemes" name="author">

  <meta property="og:site_name" content="-CUSTOMER VALUE-">
  <meta property="og:title" content="-CUSTOMER VALUE-">
  <meta property="og:description" content="-CUSTOMER VALUE-">
  <meta property="og:type" content="website">
  <meta property="og:image" content="-CUSTOMER VALUE-"><!-- link to image for socio -->
  <meta property="og:url" content="-CUSTOMER VALUE-">

  <link rel="shortcut icon" href="favicon.ico">

  <!-- Fonts START -->
  <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700|PT+Sans+Narrow|Source+Sans+Pro:200,300,400,600,700,900&amp;subset=all" rel="stylesheet" type="text/css">
  <!-- Fonts END -->

  <!-- Global styles START -->          
  <link href="../assets/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="../assets/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Global styles END --> 
   
  <!-- Page level plugin styles START -->
  <link href="../assets/global/plugins/fancybox/source/jquery.fancybox.css" rel="stylesheet">
  <link href="../assets/global/plugins/uniform/css/uniform.default.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin styles END -->

  <!-- Theme styles START -->
  <link href="../assets/global/css/components.css" rel="stylesheet">
  <link href="../assets/frontend/layout/css/style.css" rel="stylesheet">
  <link href="../assets/frontend/layout/css/style-responsive.css" rel="stylesheet">
  <link href="../assets/frontend/layout/css/themes/red.css" rel="stylesheet" id="style-color">
  <link href="../assets/frontend/layout/css/custom.css" rel="stylesheet">
  <!-- Theme styles END -->
</head>
<!-- Head END -->


	<!-- BEGIN GLOBAL MANDATORY STYLES -->
	<link href="../assets/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
	<!-- END GLOBAL MANDATORY STYLES -->
	<!-- BEGIN PAGE LEVEL STYLES -->
	<link rel="stylesheet" type="text/css" href="../assets/global/plugins/select2/select2.css"/>
	<link rel="stylesheet" type="text/css" href="../assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css"/>
	<!-- END PAGE LEVEL STYLES -->
	<!-- BEGIN THEME STYLES -->
	<link href="../assets/global/css/plugins.css" rel="stylesheet" type="text/css"/>
	<!-- END THEME STYLES -->
	<link rel="shortcut icon" href="favicon.ico"/>



<!-- Body BEGIN -->
<body class="corporate">
     
    
    <!-- BEGIN TOP BAR -->
    <div class="pre-header">
        <div class="container">
            <div class="row">
                <!-- BEGIN TOP BAR LEFT PART -->
                <div class="col-md-6 col-sm-6 additional-shop-info">
                    <ul class="list-unstyled list-inline">
                        <li><i class="fa fa-phone"></i><span>+1 456 6717</span></li>
                        <li><i class="fa fa-envelope-o"></i><span>info@binarysecuritysolutions.com</span></li>
                    </ul>
                </div>
                <!-- END TOP BAR LEFT PART -->
                <!-- BEGIN TOP BAR MENU -->
                <div class="col-md-6 col-sm-6 additional-nav">
                    <ul class="list-unstyled list-inline pull-right">
						<li><a href="searchStudent.php">Search Student</a></li>
                        <li><a href="login.php">Log In</a></li>
                    </ul>
                </div>
                <!-- END TOP BAR MENU -->
            </div>
        </div>        
    </div>
    <!-- END TOP BAR -->
    <!-- BEGIN HEADER -->
    <div class="header">
      <div class="container">
        <a class="site-logo" href="index.html"><img src="../assets/frontend/layout/img/logos/logo-corp-red.png" alt="Metronic FrontEnd"></a>

        <a href="javascript:void(0);" class="mobi-toggler"><i class="fa fa-bars"></i></a>

        <!-- BEGIN NAVIGATION -->
        <div class="header-navigation pull-right font-transform-inherit">
          <ul>
		
			<li class="<?php print $classname1;?>"><a href="agentDashboard.php">Homepage</a></li>
			<li class="<?php print $classname2;?>"><a href="manageStudentDetails.php">Manage Student</a></li>
			<li class="<?php print $classname3;?>"><a href="addStudentDetails.php">Add Student Details</a></li>
			<li><a href="logout.php">Logout</a></li>
          </ul>
        </div>
        <!-- END NAVIGATION -->
      </div>
    </div>
    <!-- Header END -->
