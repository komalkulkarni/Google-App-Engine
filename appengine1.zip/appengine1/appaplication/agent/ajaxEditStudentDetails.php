<?php
	require_once 'agentAuthorized.php';
	require_once '../functions/commonFunctions.php';
	require_once '../classes/StudentAgentModel.php';
	DatastoreService::setInstance(new DatastoreService($google_api_config));

	
	if(isset($_REQUEST['eid']))
	{
		
		$repKey=str_replace('e--','',$_POST['key']);
		
		
		$AllStudentObjArr=array();
		$fetchAllStudent = StudentAgentModel::fetch_by_name($repKey);
		$StudentAgentDetails = new StudentAgentModel();
		foreach($fetchAllStudent as $key => $val)
		{
			$AllStudentObjArr[]=$StudentAgentDetails->getCourseEmail($val);
		}
		$NewStudentArray=array_filter($AllStudentObjArr);

		
		
	
		foreach($NewStudentArray as $key2 => $val2)
		{
			$courseidOld = $NewStudentArray[$key2]['courseid'];
			$coursenameOld = $NewStudentArray[$key2]['coursename'];
			$studentname = $NewStudentArray[$key2]['studentname'];
			$certificatedate = $NewStudentArray[$key2]['certificatedate'];
			$studentid = $NewStudentArray[$key2]['studentid'];
			$certificateactivation = $NewStudentArray[$key2]['certificateactivation'];
			$agentid = $NewStudentArray[$key2]['agentid'];
			$certificateadddate =  $NewStudentArray[$key2]['certificateadddate'];
			
			$stude_modelDel = new StudentAgentModel($courseidOld,$coursenameOld,$studentname,$certificatedate,$studentid,$certificateactivation,$agentid,$certificateadddate);
			$stude_modelDel->delete();
			
			$studentagent_model = new StudentAgentModel($courseidOld,$coursenameOld,$_POST['studentname'],$_POST['certificatedate'],$_POST['studentid'],$certificateactivation,$agentid,$certificateadddate);
			$studentagent_model->put();
			print $studentagent_model->getKey($studentagent_model);
		}
		
	
		
	}
?>