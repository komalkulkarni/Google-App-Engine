<?php
	require_once 'agentAuthorized.php';
	require_once '../functions/commonFunctions.php';
	$msg="";
	
	$objArr=array();
		
	require_once '../classes/StudentAgentModel.php';
	DatastoreService::setInstance(new DatastoreService($google_api_config));

	
	$course_model_fetched = StudentAgentModel::all();
	
	
	$StudentAgentDetails = new StudentAgentModel();
	foreach($course_model_fetched as $key => $val)
	{
		$objArr[]=$StudentAgentDetails->getEditAgentName($val,$_SESSION['agentAuth']);
	}
	$NewStudentArray=array_filter($objArr);
	
	
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->

<?php 
	require_once 'includes/agentHeader.php';
?>

<div class="main">
      <div class="container">
        <ul class="breadcrumb">
            <li><a href="agentDashboard.php">Home</a></li>
            <li class="active">Dashboard</li>
        </ul>
        <!-- BEGIN SIDEBAR & CONTENT -->
        <div class="row margin-bottom-40">
         
         
         <?php 
			require_once 'includes/agentLeftMenu.php';
		?>

          <!-- BEGIN CONTENT -->
          <div class="col-md-9 col-sm-9">
            <div class="content-form-page">
              <div class="row">
				<div class="col-md-12">
					<!-- BEGIN PAGE TITLE & BREADCRUMB-->
					<h3 class="page-title">Welcome User!</h3>
						
						
					<!-- BEGIN EXAMPLE TABLE PORTLET-->
					<div class="portlet box blue">
						<div class="portlet-title">
							<div class="caption">
								<i class="fa fa-edit"></i>Manage Student Courses
							</div>
							<div class="tools">
								<a href="javascript:;" class="collapse">
								</a>
								<a href="#portlet-config" data-toggle="modal" class="config">
								</a>
								<a href="javascript:;" class="reload">
								</a>
								<a href="javascript:;" class="remove">
								</a>
							</div>
						</div>
						<div class="portlet-body">
							<div class="table-toolbar">
								<!--<div class="btn-group">
									<button id="sample_editable_1_new" class="btn green">
									Add New <i class="fa fa-plus"></i>
									</button>
								</div>-->
								<div class="btn-group pull-right">
									<button class="btn dropdown-toggle" data-toggle="dropdown">Tools <i class="fa fa-angle-down"></i>
									</button>
									<ul class="dropdown-menu pull-right">
										<li>
											<a href="#">
											Print </a>
										</li>
										<li>
											<a href="#">
											Save as PDF </a>
										</li>
										<li>
											<a href="#">
											Export to Excel </a>
										</li>
									</ul>
								</div>
							</div>
							<table class="table table-striped table-hover table-bordered" id="sample_editable_1">
							<thead>
							<tr>
								<th>Course Name</th>
								<th>Student Name</th>
								<th>Student Id</th>
								<th>Certification date</th>
								<th>Active Status</th>
								<th>Edit</th>
							</tr>
							
							</thead>
							<tbody>
							<?php 
								foreach($NewStudentArray as $key => $val)
								{
							?>
									<tr id="p<?php echo $val['datakey']; ?>">
										<td><?php print $val['coursename'];?></td>
										<td><?php print $val['studentname'];?></td>
										<td><?php print $val['studentid'];?></td>
										<td><?php print $val['certificatedate'];?></td>
										<td><?php if($val['certificateactivation']=='N') print "Suspend";else print "Active";?></td>
										<td id="e--<?php echo $val['datakey']; ?>" >
										<?php
										if($val['certificateactivation']=='N')
										{
										?>
											<a class="edit" href="javascript:;">
											Edit </a>
										<?php } else print '';?>
										</td>
										
									</tr>
							<?php
								}
							?>
									
									
							
							
							</tbody>
							</table>
						</div>
					</div>
					<!-- END EXAMPLE TABLE PORTLET-->
				</div>
               
              </div>
            </div>
          </div>
          <!-- END CONTENT -->
        </div>
        <!-- END SIDEBAR & CONTENT -->
      </div>
    </div>

	<?php 
		require_once 'includes/agentFooter.php';
	?>
<script>
function addFunc(studentname,studentid,certificatedate,k)
		{
			
			if(k=='' || k==undefined)
			{
				return false;
			}
			else	
			{
				
				var dataString = {studentname:studentname, studentid:studentid, certificatedate:certificatedate, key: k,eid:'edit'};	
				$.ajax({
				   type: "POST",
				   url: "ajaxEditStudentDetails.php",
				   data: dataString,
				   cache: false,

				   success: function(data)
				   {
						var textTitle = k;
						
						var result = textTitle.replace('e--', '');
						
						var pid1 = 'p'+result;
						var ehashid1 = k;
						var normalid1 = result;

						$('#'+pid1 ).attr( "id", 'p'+data);
						$('#'+ehashid1 ).attr( "id", 'e--'+data);
						$('#'+normalid1 ).attr( "id", data);
				   }
				   
				 });
				
				return false;
			}
			
		}
		
		
	</script>
<script src="../assets/agent/pages/scripts/agenttable-editable.js"></script>
<script>
    jQuery(document).ready(function() {    
       Metronic.init(); // init metronic core components
Layout.init(); // init current layout
QuickSidebar.init() // init quick sidebar
TableEditable.init();
    });
  </script>
<!-- END JAVASCRIPTS -->


</body>
<!-- END BODY -->
</html>
					