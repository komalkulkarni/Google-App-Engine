<div id="sidebar1" class="sidebar">
	<ul>
		<li>
			<h2>Recent Posts</h2>
			<ul>
				<li><a href="agentDashboard.php">Homepage</a></li>
				<li><a href="manageStudentDetails.php">Manage Student</a></li>
				<li><a href="addStudentDetails.php">Add Student Details</a></li>
				<li><a href="logout.php">Logout</a></li>
				
			</ul>
		</li>
		
	</ul>
</div>

