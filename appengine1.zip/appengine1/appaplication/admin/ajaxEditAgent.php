<?php
	require_once 'adminAuthorized.php';
	require_once '../functions/commonFunctions.php';
	require_once '../classes/AgentModel.php';
	require_once '../classes/StudentAgentModel.php';
	DatastoreService::setInstance(new DatastoreService($google_api_config));

	$agent_model = new AgentModel();
	
	if(isset($_REQUEST['eid']))
	{
	
		
		$repKey=str_replace('e--','',$_POST['key']);
		$AllStudentObjArr=array();
		$fetchAllStudent = StudentAgentModel::all();
		$StudentAgentDetails = new StudentAgentModel();
		foreach($fetchAllStudent as $key => $val)
		{
			$AllStudentObjArr[]=$StudentAgentDetails->getEditAgentName($val,$repKey);
		}
		$NewStudentArray=array_filter($AllStudentObjArr);

		
		//edit
		$agentInfofetched = AgentModel::fetch_by_name($repKey);
		$objArr=array();
		foreach($agentInfofetched as $key => $val)
		{
			$objArr[]=$agent_model->getAgentEmail($val);
		}
		
		$agent_modelDel = new AgentModel($objArr['0']['email'],$objArr['0']['password']);
		$agent_modelDel->delete();
		
		if($_POST['a']=='Active')
			$agentActivation = 'Y';
		else
			$agentActivation = 'N';
			
		$agent_model = new AgentModel($_POST['email'],$_POST['psw'],$agentActivation);
		$agent_model->put();
		print $keyAgent=$agent_model->getKey($agent_model);
		
		
		foreach($NewStudentArray as $key2 => $val2)
		{
			$courseidOld = $NewStudentArray[$key2]['courseid'];
			$coursenameOld = $NewStudentArray[$key2]['coursename'];
			$studentname = $NewStudentArray[$key2]['studentname'];
			$certificatedate = $NewStudentArray[$key2]['certificatedate'];
			$studentid = $NewStudentArray[$key2]['studentid'];
			$certificateactivation = $NewStudentArray[$key2]['certificateactivation'];
			$agentid = $NewStudentArray[$key2]['agentid'];
			$certificateadddate =  $NewStudentArray[$key2]['certificateadddate'];
			
			$stude_modelDel = new StudentAgentModel($courseidOld,$coursenameOld,$studentname,$certificatedate,$studentid,$certificateactivation,$agentid,$certificateadddate);
			$stude_modelDel->delete();
			
			$studentagent_model = new StudentAgentModel($courseidOld,$coursenameOld,$studentname,$certificatedate,$studentid,$certificateactivation,$keyAgent,$certificateadddate);
			$studentagent_model->put();
		}
		
	
		
	}
?>