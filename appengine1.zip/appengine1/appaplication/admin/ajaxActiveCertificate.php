<?php
	require_once 'adminAuthorized.php';
	require_once '../functions/commonFunctions.php';
	require_once '../classes/StudentAgentModel.php';
	DatastoreService::setInstance(new DatastoreService($google_api_config));

	$student_model = new StudentAgentModel();
	

	if(isset($_POST['tid']))
	{
		$studentInfofetched = StudentAgentModel::fetch_by_name($_POST['tid']);
		
		$objArr=array();
		
		foreach($studentInfofetched as $key => $val)
		{
			$objArr[]=$student_model->getCourseEmail($val);
		}
		
		if($objArr['0']['certificateactivation']=='Y')
			$certificateactivation = 'N';
		else
			$certificateactivation = 'Y';
		
		
			
		$student_model_instance = new StudentAgentModel($objArr['0']['courseid'],$objArr['0']['coursename'],$objArr['0']['studentname'],$objArr['0']['certificatedate'],$objArr['0']['studentid'],$certificateactivation,$objArr['0']['agentid'],$objArr['0']['certificateadddate']);

		$student_model_instance->put();
			
		print "Student Edit.";
	}
	
	elseif(isset($_POST['did']))
	{
		$studentInfofetched = StudentAgentModel::fetch_by_name($_POST['did']);
		
		$objArr=array();
		foreach($studentInfofetched as $key => $val)
		{
			$objArr[]=$student_model->getCourseEmail($val);
			
		}
		
		$StudentAgentModel = new StudentAgentModel($objArr['0']['courseid'],$objArr['0']['coursename'],$objArr['0']['studentname'],$objArr['0']['certificatedate'],$objArr['0']['studentid'],$objArr['0']['certificateactivation'],$objArr['0']['agentid']);

		$StudentAgentModel->delete();
		
		print "Student Certification Deleted";
	}	
	
	elseif(isset($_POST['eid']))
	{
		//print "<pre>";
		//print_r($_POST);
		//print "</pre>";
		
		
		$repKey=str_replace('e--','',$_POST['key']);
		$agentInfofetched = StudentAgentModel::fetch_by_name($repKey);
		$objArr=array();
		$StudentAgentDetails = new StudentAgentModel();
		foreach($agentInfofetched as $key => $val)
		{
			$objArr[]=$StudentAgentDetails->getCourseEmail($val);
		}
		$agent_modelDel = new StudentAgentModel($objArr['0']['courseid'],$objArr['0']['coursename'],$objArr['0']['studentname'],$objArr['0']['certificatedate'],$objArr['0']['studentid'],$objArr['0']['certificateactivation'],$objArr['0']['agentid'],$objArr['0']['certificateadddate']);
		$agent_modelDel->delete();
	
		$courseid = sha1($_POST['coursename']);
		$coursename = $_POST['coursename'];
		$studentname = $_POST['studentname'];
		$certificatedate = $_POST['certificatedate'];
		$studentid = $_POST['studentid'];
		$certificateactivation = $_POST['certificateactivation'];
		$agentid = $_POST['agentid'];
		$certificateadddate = '';

		$studentagent_model = new StudentAgentModel($courseid,$coursename,$studentname,$certificatedate,$studentid,$certificateactivation,$agentid,$certificateadddate);

		$studentagent_model->put();
		print $studentagent_model->getKey($studentagent_model);
	}
?>