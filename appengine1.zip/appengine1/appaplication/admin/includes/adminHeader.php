<?php
	if(basename($_SERVER['SCRIPT_NAME'])=='adminDashboard.php')
		$classname1='classic-menu-dropdown active';
	else
		$classname1='mega-menu-dropdown';
		
	if(basename($_SERVER['SCRIPT_NAME'])=='manageAgent.php')
		$classname2='classic-menu-dropdown active';
	else
		$classname2='mega-menu-dropdown';
		
	if(basename($_SERVER['SCRIPT_NAME'])=='manageCourses.php')
		$classname3='classic-menu-dropdown active';
	else
		$classname3='mega-menu-dropdown';
		
	if(basename($_SERVER['SCRIPT_NAME'])=='addAgent.php')
		$classname4='classic-menu-dropdown active';
	else
		$classname4='mega-menu-dropdown';
		
	if(basename($_SERVER['SCRIPT_NAME'])=='addCourse.php')
		$classname5='classic-menu-dropdown active';
	else
		$classname5='mega-menu-dropdown';
		
	if(basename($_SERVER['SCRIPT_NAME'])=='approveCertification.php')
		$classname6='classic-menu-dropdown active';
	else
		$classname6='mega-menu-dropdown';
		
	if(basename($_SERVER['SCRIPT_NAME'])=='searchResult.php')
		$classname7='classic-menu-dropdown active';
	else
		$classname7='mega-menu-dropdown';
	

?>
<!-- BEGIN HEAD -->
<head>
	<meta charset="utf-8"/>
	<title>Certificate Validate Portal | Admin Dashboard</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
	<meta content="" name="description"/>
	<meta content="" name="author"/>
	<!-- BEGIN GLOBAL MANDATORY STYLES -->
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css"/>
	<link href="../assets/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
	<link href="../assets/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css"/>
	<link href="../assets/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
	<link href="../assets/global/plugins/uniform/css/uniform.default.css" rel="stylesheet" type="text/css"/>
	<link href="../assets/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css"/>
	<!-- END GLOBAL MANDATORY STYLES -->
	<!-- BEGIN PAGE LEVEL STYLES -->
	<link rel="stylesheet" type="text/css" href="../assets/global/plugins/select2/select2.css"/>
	<link rel="stylesheet" type="text/css" href="../assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css"/>
	<!-- END PAGE LEVEL STYLES -->
	<!-- BEGIN THEME STYLES -->
	<link href="../assets/global/css/components.css" rel="stylesheet" type="text/css"/>
	<link href="../assets/global/css/plugins.css" rel="stylesheet" type="text/css"/>
	<link href="../assets/admin/layout/css/layout.css" rel="stylesheet" type="text/css"/>
	<link id="style_color" href="../assets/admin/layout/css/themes/default.css" rel="stylesheet" type="text/css"/>
	<link href="../assets/admin/layout/css/custom.css" rel="stylesheet" type="text/css"/>
	<!-- END THEME STYLES -->
	<link rel="shortcut icon" href="favicon.ico"/>
</head>
<!-- BEGIN HEADER -->
<div class="page-header navbar navbar-fixed-top">
	<!-- BEGIN HEADER INNER -->
	<div class="page-header-inner">
		<!-- BEGIN LOGO -->
		<div class="page-logo">
			<a href="index.html">
			<img src="../assets/admin/layout/img/logo.png" alt="logo" class="logo-default"/>
			</a>
			
		</div>
		<!-- END LOGO -->
		<!-- BEGIN HORIZANTAL MENU -->
		<!-- DOC: Remove "hor-menu-light" class to have a horizontal menu with theme background instead of white background -->
		<!-- DOC: This is desktop version of the horizontal menu. The mobile version is defined(duplicated) in the responsive menu below along with sidebar menu. So the horizontal menu has 2 seperate versions -->
		<div class="hor-menu hor-menu-light hidden-sm hidden-xs">
			<ul class="nav navbar-nav">
				<!-- DOC: Remove data-hover="dropdown" and data-close-others="true" attributes below to disable the horizontal opening on mouse hover -->
				<li class="<?php print $classname1;?>"><a href="adminDashboard.php">Homepage<span class="selected"></span></a></li>
								<li class="<?php print $classname4;?>"><a href="addAgent.php">Add Agents</a></li>

				<li class="<?php print $classname2;?>"><a href="manageAgent.php">Manage Agents</a></li>
								<li class="<?php print $classname5;?>"><a href="addCourse.php">Add Course</a></li>

				<li class="<?php print $classname3;?>"><a href="manageCourses.php">Manage Courses</a></li>
				<li class="<?php print $classname6;?>"><a href="approveCertification.php">Approve Certificate</a></li>
				<li class="<?php print $classname7;?>"><a href="searchResult.php">Search</a></li>
				<li class="mega-menu-dropdown"><a href="logout.php">Logout</a></li>
			</ul>
		</div>
		<!-- END HORIZANTAL MENU -->
		<!-- BEGIN HEADER SEARCH BOX -->
		<!-- DOC: Apply "search-form-expanded" right after the "search-form" class to have half expanded search box -->
		<form class="search-form" action="extra_search.html" method="GET">
			<div class="input-group">
				<input type="text" class="form-control" placeholder="Search..." name="query">
				<span class="input-group-btn">
				<a href="javascript:;" class="btn submit"><i class="icon-magnifier"></i></a>
				</span>
			</div>
		</form>
		<!-- END HEADER SEARCH BOX -->
		
	</div>
	<!-- END HEADER INNER -->
</div>
<!-- END HEADER -->
<div class="clearfix">
</div>