<!-- start sidebars -->
<div id="sidebar2" class="sidebar">
	<ul>
		<li>
			<form id="searchform" method="get" action="#">
				<div>
					<h2>Site Search</h2>
					<input type="text" name="s" id="s" size="15" value="" />
				</div>
			</form>
		</li>
	</ul>
</div>
<!-- end sidebars -->