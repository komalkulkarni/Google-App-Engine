<?php
	if(basename($_SERVER['SCRIPT_NAME'])=='adminDashboard.php')
		$classname1='active';
	else
		$classname1='';
		
	if(basename($_SERVER['SCRIPT_NAME'])=='addAgent.php')
		$classname2='active';
	else
		$classname2='';
		
	if(basename($_SERVER['SCRIPT_NAME'])=='manageAgent.php')
		$classname3='active';
	else
		$classname3='';
		
	if(basename($_SERVER['SCRIPT_NAME'])=='addCourse.php')
		$classname4='active';
	else
		$classname4='';
		
	if(basename($_SERVER['SCRIPT_NAME'])=='manageCourses.php')
		$classname5='active';
	else
		$classname5='';
		
		
	if(basename($_SERVER['SCRIPT_NAME'])=='approveCertification.php')
		$classname6='active';
	else
		$classname6='';
		
	if(basename($_SERVER['SCRIPT_NAME'])=='searchResult.php')
		$classname7='active';
	else
		$classname7='';
	
	if(basename($_SERVER['SCRIPT_NAME'])=='adminsettings.php')
		$classname0='active';
	else
		$classname0='';
?>

	<!-- BEGIN SIDEBAR -->
	<div class="page-sidebar-wrapper">
		<div class="page-sidebar navbar-collapse collapse">
			<!-- BEGIN SIDEBAR MENU1 -->
			<ul class="page-sidebar-menu hidden-sm hidden-xs" data-auto-scroll="false" data-slide-speed="200">
				<!-- DOC: To remove the search box from the sidebar you just need to completely remove the below "sidebar-search-wrapper" LI element -->
				<!-- DOC: This is mobile version of the horizontal menu. The desktop version is defined(duplicated) in the header above -->
				<li class="sidebar-search-wrapper">
					<!-- BEGIN RESPONSIVE QUICK SEARCH FORM -->
					<!-- DOC: Apply "sidebar-search-bordered" class the below search form to have bordered search box -->
					<!-- DOC: Apply "sidebar-search-bordered sidebar-search-solid" class the below search form to have bordered & solid search box -->
					<form class="sidebar-search sidebar-search-bordered" action="extra_search.html" method="POST">
						
						<div class="input-group">
							<input type="text" class="form-control" placeholder="Search...">
							<span class="input-group-btn">
							<button class="btn submit"><i class="icon-magnifier"></i></button>
							</span>
						</div>
					</form>
					<!-- END RESPONSIVE QUICK SEARCH FORM -->
				</li>
				
				<li class="start active open">
					<a href="javascript:;">
					<i class="fa fa-cogs"></i>
					<span class="title">
					Page Layouts </span>
					<span class="arrow open">
					</span>
					<span class="selected"></span>
					</a>
					<ul class="sub-menu">
						
						<li class="<?php print $classname0;?>"><a href="adminsettings.php">Admin Settings</a></li>
						<li class="<?php print $classname1;?>"><a href="adminDashboard.php">Homepage</a></li>
						<li class="<?php print $classname2;?>"><a href="addAgent.php">Add Agent</a></li>
						<li class="<?php print $classname3;?>"><a href="manageAgent.php">Manage Agents</a></li>
						<li class="<?php print $classname4;?>"><a href="addCourse.php">Add Course</a></li>
						<li class="<?php print $classname5;?>"><a href="manageCourses.php">Manage Courses</a></li>
						<li class="<?php print $classname6;?>"><a href="approveCertification.php">Approve Certification</a></li>
						<li class="<?php print $classname7;?>"><a href="searchResult.php">Search</a></li>
						<li><a href="logout.php">Logout</a></li>
						
						
					</ul>
				</li>
			</ul>
			<!-- END SIDEBAR MENU1 -->
			
		</div>
	</div>
	<!-- END SIDEBAR -->