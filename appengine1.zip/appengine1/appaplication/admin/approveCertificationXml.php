<?php  
	require_once 'adminAuthorized.php';
	
	
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');

    // change this line to change the filename it saves as
    header('Content-Disposition: attachment; filename=studentCertification.xml');

    header('Content-Transfer-Encoding: binary');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public'); 

    // your code goes here 
	$msg="";
    ini_set ("display_errors", "1");
    error_reporting(E_ALL);
    
    require_once '../functions/commonFunctions.php';

	$objArr=array();
		
	require_once '../classes/StudentAgentModel.php';
	require_once '../classes/AgentModel.php';
										
	DatastoreService::setInstance(new DatastoreService($google_api_config));

	
	$course_model_fetched = StudentAgentModel::all();
	
	
	$StudentAgentDetails = new StudentAgentModel();
	foreach($course_model_fetched as $key => $val)
	{
		$objArr[]=$StudentAgentDetails->getCourseEmail($val);
	}
	$NewStudentArray=array_filter($objArr);
	$agent_model = new AgentModel();
	
    
    if(count($NewStudentArray) > 0){
	echo '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . "\n";     
	echo "<response>\n";
        foreach($NewStudentArray as $key => $val)
		{
			$agentObjArr=array();
			$searchAgentKey=$val['agentid'];
			
			$agentDetails = AgentModel::fetch_by_name($searchAgentKey);
			
			foreach($agentDetails as $key1 => $val1)
			{
				$agentObjArr[]=$agent_model->getAgentEmail($val1);
			}
		
				if($val['certificateactivation']=='Y') 
					$status="Active";
				else
					$status="Suspend";
		 echo "<Certification>\n"; 
		 echo "<CourseName>" . htmlspecialchars($val['coursename']) . "</CourseName>\n";
		 echo "<AgentName>" . htmlspecialchars($agentObjArr['0']['email']) . "</AgentName>\n";
		 echo "<StudentName>" . htmlspecialchars($val['studentname']) . "</StudentName>\n";
		 echo "<StudentId>" . htmlspecialchars($val['studentid']) . "</StudentId>\n";
		 echo "<CertificationDate>" . htmlspecialchars($val['certificatedate']) . "</CertificationDate>\n";
		 echo "<ActiveStatus>" . htmlspecialchars($status) . "</ActiveStatus>\n";
		 echo "</Certification>\n";
   
        }
		echo "</response>\n";
	}
    