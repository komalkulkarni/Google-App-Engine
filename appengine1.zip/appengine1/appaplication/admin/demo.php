<?php
const APP_NAME='certificatevalidate2';
const SERVICE_ACCOUNT_NAME='232091413818-s6vcnj95ih077id8g9qe6onjamlgduhr@developer.gserviceaccount.com ';
$_PRIVATE_KEY=file_get_contents('../secure_private_key/236750c403aca98f7df3f7d5ed8b0f5bd2328782-privatekey.p12');
require_once 'src/Google_Client.php';

$client=new Google_Client();
$credentials=new Google_AssertionCredentials(SERVICE_ACCOUNT_NAME,
                                             array('https://www.googleapis.com/auth/userinfo.email',
                                                   'https://www.googleapis.com/auth/datastore'
                                                  ),
                                             $_PRIVATE_KEY
                                            );
$client->setAssertionCredentials($credentials);

$postBody=json_encode(array('gqlQuery'=>array('allowLiteral'=>true, 'queryString'=>
          "SELECT * FROM StudentCertificate WHERE coursename='c6'"
          )));
$httpRequest=new Google_HttpRequest('datastore/v1beta2/datasets/'.APP_NAME.'/runQuery', 'POST', null, $postBody);
$head=array('content-type'=>'application/json; charset=UTF-8',
            'content-length'=>Google_Utils::getStrLen($postBody)
           );
$httpRequest->setRequestHeaders($head);
$httpRequest=Google_Client::$auth->sign($httpRequest);
$result=Google_REST::execute($httpRequest);
print "<pre>";var_export($result);print "</pre>";
?>


	
