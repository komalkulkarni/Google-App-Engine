<?php
	require_once 'adminAuthorized.php';
	require_once '../functions/commonFunctions.php';
	require_once '../classes/CourseModel.php';
	DatastoreService::setInstance(new DatastoreService($google_api_config));

	$course_model = new CourseModel();
	
	if(isset($_POST['did']))
	{
		$courseInfofetched = CourseModel::fetch_by_name($_POST['did']);
		
		$objArr=array();
		foreach($courseInfofetched as $key => $val)
		{
			$objArr[]=$course_model->getCourseEmail($val);
			
		}
		$course_model = new CourseModel($objArr['0']['coursename']);
		$course_model->delete();
		
		print "Course Deleted";
	}
	
	elseif(isset($_REQUEST['eid']))
	{
		
		
		$repKey=str_replace('e--','',$_POST['key']);
		$courseInfofetched = CourseModel::fetch_by_name($repKey);
		$objArr=array();
		foreach($courseInfofetched as $key => $val)
		{
			$objArr[]=$course_model->getCourseEmail($val);
		}
		
		$course_modelDel = new CourseModel($objArr['0']['coursename']);
		$course_modelDel->delete();
		
		
		$courseName = htmlspecialchars($_POST['coursename']);
		$courseDescription = htmlspecialchars($_POST['coursedescription']);
		$courseActivation = 'Y';	
		
		$course_model = new CourseModel($courseName,$courseDescription,$courseActivation);

		$course_model->put();
			
		print sha1($courseName);
		
		
	}
?>