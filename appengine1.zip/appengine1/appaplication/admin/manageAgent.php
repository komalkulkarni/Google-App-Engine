<?php
	require_once 'adminAuthorized.php';
	require_once '../functions/commonFunctions.php';
	$msg="";
	
	$objArr=array();
		
	require_once '../classes/AgentModel.php';
	DatastoreService::setInstance(new DatastoreService($google_api_config));

	
	$agent_model_fetched = AgentModel::all();
	
	$aaa = new AgentModel();
	foreach($agent_model_fetched as $key => $val)
	{
		$objArr[]=$aaa->getAgentEmail($val);
		
	}
	
?>
<!DOCTYPE html>

<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en" >
<!--<![endif]-->

<!-- BEGIN BODY -->
<!-- DOC: Apply "page-header-fixed-mobile" and "page-footer-fixed-mobile" class to body element to force fixed header or footer in mobile devices -->
<!-- DOC: Apply "page-sidebar-closed" class to the body and "page-sidebar-menu-closed" class to the sidebar menu element to hide the sidebar by default -->
<!-- DOC: Apply "page-sidebar-hide" class to the body to make the sidebar completely hidden on toggle -->
<!-- DOC: Apply "page-sidebar-closed-hide-logo" class to the body element to make the logo hidden on sidebar toggle -->
<!-- DOC: Apply "page-sidebar-hide" class to body element to completely hide the sidebar on sidebar toggle -->
<!-- DOC: Apply "page-sidebar-fixed" class to have fixed sidebar -->
<!-- DOC: Apply "page-footer-fixed" class to the body element to have fixed footer -->
<!-- DOC: Apply "page-sidebar-reversed" class to put the sidebar on the right side -->
<!-- DOC: Apply "page-full-width" class to the body element to have full width page without the sidebar menu -->
<body class="page-header-fixed page-quick-sidebar-over-content page-sidebar-closed-hide-logo">
	<?php 
		require_once 'includes/adminHeader.php';
	?>
<!-- BEGIN CONTAINER -->
<div class="page-container">
	<?php 
		require_once 'includes/adminLeftMenu.php';
	?>
	<!-- BEGIN CONTENT -->
	<div class="page-content-wrapper">
		<div class="page-content">
			
			<!-- BEGIN PAGE HEADER-->
			<div class="row">
				<div class="col-md-12">
					<!-- BEGIN PAGE TITLE & BREADCRUMB-->
					<h3 class="page-title">Welcome Admin User!</h3>
					<?php if($msg!=''){ print "<h3>".$msg."</h3>";}?>
					
					<!-- BEGIN EXAMPLE TABLE PORTLET-->
					<div class="portlet box blue">
						<div class="portlet-title">
							<div class="caption">
								<i class="fa fa-edit"></i>Manage Agent Users
							</div>
							<div class="tools">
								<a href="javascript:;" class="collapse">
								</a>
								<a href="#portlet-config" data-toggle="modal" class="config">
								</a>
								<a href="javascript:;" class="reload">
								</a>
								<a href="javascript:;" class="remove">
								</a>
							</div>
						</div>
						<div class="portlet-body">
							<div class="table-toolbar">
								<!--<div class="btn-group">
									<button id="sample_editable_1_new" class="btn green">
									Add New <i class="fa fa-plus"></i>
									</button>
								</div>-->
								<!--<div class="btn-group pull-right">
									<button class="btn dropdown-toggle" data-toggle="dropdown">Tools <i class="fa fa-angle-down"></i>
									</button>
									<ul class="dropdown-menu pull-right">
										<li>
											<a href="#">
											Print </a>
										</li>
										<li>
											<a href="#">
											Save as PDF </a>
										</li>
										<li>
											<a href="#">
											Export to Excel </a>
										</li>
									</ul>
								</div>-->
							</div>
							<table class="table table-striped table-hover table-bordered" id="sample_editable_1">
							<thead>
							<tr>
								<th>
									 Email
								</th>
								<th>
									 Password
								</th>
								<th>
									 Active / Suspend
								</th>
								
								
								<th>
									 Edit
								</th>
								<th>
									 Delete
								</th>
							</tr>
							</thead>
							<tbody>
							<?php 
							$keyArr=array();
							$i=0;
							foreach($objArr as $key => $val)
							{
								$keyArr[$i]=$val['datakey'];
								$i++;
							?>
									<tr id="p<?php echo $val['datakey']; ?>" >
										<td><?php print $val['email'];?></td>
										<td><?php print $val['password'];?></td>
										<td id="c<?php echo $val['datakey']; ?>"><?php if($val['agentactivation']=='Y') print "<a href='#' onclick=\"activeDeactive('".$val['datakey']."','N')\">Suspend</a>";else print "<a href='#' onclick=\"activeDeactive('".$val['datakey']."','Y')\">Activate</a>";?></td>
										
										<td id="e--<?php echo $val['datakey']; ?>" >
											<a class="edit" href="javascript:;">
											Edit </a>
										</td>
										<td id="<?php echo $val['datakey']; ?>">
											<a class="delete" href="#">
											Delete </a>
										</td>
									</tr>
							<?php
							}
							?>
							
							</tbody>
							</table>
						</div>
					</div>
					<!-- END EXAMPLE TABLE PORTLET-->
				</div>
			</div>
			<!-- END PAGE HEADER-->
			
		</div>
	</div>
	<!-- END CONTENT -->
	
</div>
<!-- END CONTAINER -->

<?php 
	require_once 'includes/adminFooter.php';
?>
<script src="../assets/admin/pages/scripts/agenttable-editable.js"></script>
<script>
    jQuery(document).ready(function() {    
       Metronic.init(); // init metronic core components
Layout.init(); // init current layout
QuickSidebar.init() // init quick sidebar
TableEditable.init();
    });
  </script>
<!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>
	
							
						
						
	
	<script type="text/javascript">
		$(function() {
		$(".delete_button").click(function() {
		var id = $(this).attr("id");
		var pid = 'p'+$(this).attr("id");
		var dataString = 'did='+ id ;
		var parent = $(this).parent();
			
		$.ajax({
		   type: "POST",
		   url: "modifyAgent.php",
		   data: dataString,
		   cache: false,

		   success: function()
		   {
				$('#'+pid).remove();
				
		  }
		   
		 });

		return false;
			});
		});
		
		function activeDeactive(key,value)
		{
			
			var id = key;
			var pid = 'p'+key;
			var cid = 'c'+key;
			var dataString = 'tid='+ id ;
			var parent = $(this).parent();
				
			$.ajax({
			   type: "POST",
			   url: "modifyAgent.php",
			   data: dataString,
			   cache: false,

			   success: function()
			   {
					if(value=='Y')
						$('#'+cid).html("<a href='#' onclick=\"activeDeactive('"+key+"','N')\">Suspend</a>");
					else
						$('#'+cid).html("<a href='#' onclick=\"activeDeactive('"+key+"','Y')\">Activate</a>");
			   }
			   
			 });

			return false;
		}
		
		function deleteFunc(key)
		{
			var id = key;
			var dataString = 'did='+ id ;
				
			$.ajax({
			   type: "POST",
			   url: "modifyAgent.php",
			   data: dataString,
			   cache: false,

			   success: function()
			   {
					
			   }
			   
			 });

			return false;
		
		}
		
		function addFunc(e,p,a,k)
		{
			
			if(k=='' || k==undefined)
			{
				var dataString = {email: e, psw: p, a: a, key: k, aid:'add'};	
				$.ajax({
				   type: "POST",
				   url: "modifyAgent.php",
				   data: dataString,
				   cache: false,
				   success: function(data)
				   {
						
						
				   }
				   
				 });

				return false;
			}
			else	
			{
				var dataString = {email: e, psw: p, a: a, key: k, eid:'edit'};	
				$.ajax({
				   type: "POST",
				   url: "ajaxEditAgent.php",
				   data: dataString,
				   cache: false,

				   success: function(data)
				   {
						var textTitle = k;
						
						var result = textTitle.replace('e--', '');
						
						var cid = 'c'+result;
						
						if(a=='Active')
							$('#'+cid).html("<a href='#' onclick=\"activeDeactive('"+data+"','N')\">Suspend</a>");
						else
							$('#'+cid).html("<a href='#' onclick=\"activeDeactive('"+data+"','Y')\">Active</a>");
							
						var cid1 = 'c'+result;
						var pid1 = 'p'+result;
						var ehashid1 = k;
						var normalid1 = result;

						$('#'+cid1 ).attr( "id", 'c'+data);
						$('#'+pid1 ).attr( "id", 'p'+data);
						$('#'+ehashid1 ).attr( "id", 'e--'+data);
						$('#'+normalid1 ).attr( "id", data);
				   }
				   
				 });

				return false;
			}
			
		}
		
		
	</script>

	
