<?php
	require_once 'adminAuthorized.php';
	require_once '../functions/commonFunctions.php';
	$msg="";
	$objArr=array();
		
	require_once '../classes/StudentAgentModel.php';
	require_once '../classes/AgentModel.php';
										
	DatastoreService::setInstance(new DatastoreService($google_api_config));

	
	$course_model_fetched = StudentAgentModel::all();
	
	$StudentAgentDetails = new StudentAgentModel();
	foreach($course_model_fetched as $key => $val)
	{
		$objArr[]=$StudentAgentDetails->getCourseEmail($val);
	}
	$NewStudentArray=array_filter($objArr);
	
?>
<!DOCTYPE html>

<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en" >
<!--<![endif]-->

<!-- BEGIN BODY -->
<!-- DOC: Apply "page-header-fixed-mobile" and "page-footer-fixed-mobile" class to body element to force fixed header or footer in mobile devices -->
<!-- DOC: Apply "page-sidebar-closed" class to the body and "page-sidebar-menu-closed" class to the sidebar menu element to hide the sidebar by default -->
<!-- DOC: Apply "page-sidebar-hide" class to the body to make the sidebar completely hidden on toggle -->
<!-- DOC: Apply "page-sidebar-closed-hide-logo" class to the body element to make the logo hidden on sidebar toggle -->
<!-- DOC: Apply "page-sidebar-hide" class to body element to completely hide the sidebar on sidebar toggle -->
<!-- DOC: Apply "page-sidebar-fixed" class to have fixed sidebar -->
<!-- DOC: Apply "page-footer-fixed" class to the body element to have fixed footer -->
<!-- DOC: Apply "page-sidebar-reversed" class to put the sidebar on the right side -->
<!-- DOC: Apply "page-full-width" class to the body element to have full width page without the sidebar menu -->
<body class="page-header-fixed page-quick-sidebar-over-content page-sidebar-closed-hide-logo">
	<?php 
		require_once 'includes/adminHeader.php';
	?>

<!-- BEGIN CONTAINER -->
<div class="page-container">
	<!-- BEGIN SIDEBAR -->
	<?php 
		require_once 'includes/adminLeftMenu.php';
	?>
	<!-- END SIDEBAR -->
	<!-- BEGIN CONTENT -->
	<div class="page-content-wrapper">
		<div class="page-content">
			<!-- BEGIN SAMPLE PORTLET CONFIGURATION MODAL FORM-->
			<div class="modal fade" id="portlet-config" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
							<h4 class="modal-title">Modal title</h4>
						</div>
						<div class="modal-body">
							 Widget settings form goes here
						</div>
						<div class="modal-footer">
							<button type="button" class="btn blue">Save changes</button>
							<button type="button" class="btn default" data-dismiss="modal">Close</button>
						</div>
					</div>
					<!-- /.modal-content -->
				</div>
				<!-- /.modal-dialog -->
			</div>
			<!-- /.modal -->
			<!-- END SAMPLE PORTLET CONFIGURATION MODAL FORM-->
			
			<!-- BEGIN PAGE HEADER-->
			<div class="row">
				<div class="col-md-12">
					<!-- BEGIN PAGE TITLE & BREADCRUMB-->
					<h3 class="page-title">
					Search Results <small>search results</small>
					</h3>
					<ul class="page-breadcrumb breadcrumb">
						
						<li>
							<i class="fa fa-home"></i>
							<a href="adminDashboard.php">Home</a>
							<i class="fa fa-angle-right"></i>
						</li>
						
						<li>
							<a href="#">Search Results</a>
						</li>
					</ul>
					<!-- END PAGE TITLE & BREADCRUMB-->
				</div>
			</div>
			<!-- END PAGE HEADER-->
			<!-- BEGIN PAGE CONTENT-->
			<div class="row">
				<div class="col-md-12">
					<div class="tabbable tabbable-custom tabbable-full-width">
						<ul class="nav nav-tabs">
							
							<li>
								<a data-toggle="tab" href="#tab_1_3">
								Classic Search </a>
							</li>
							
						</ul>
						<div class="tab-content">
							
							
							<div id="tab_1_3" class="tab-pane active">
								<div class="row search-form-default">
									<div class="col-md-12">
										<form class="form-inline" action="" method="POST">
											<div class="input-group">
												<div class="input-cont">
													<input type="text" name="search" placeholder="Search..." class="form-control" required/>
												</div>
												<span class="input-group-btn">
												<button type="submit" class="btn green">
												Search &nbsp; <i class="m-icon-swapright m-icon-white"></i>
												</button>
												</span>
											</div>
										</form>
									</div>
								</div>
								<?php 
									$string="";
									/*
									$array = array('dingo', 'wombat', 'kangaroo', 'platypus');

									//$strings = array('dins', 'bars', 'kangs');
									//echo  substr_in_array( $strings, $array ) ? 'found' : 'not found';

									$string = 'plat';
									echo substr_in_array( $string, $array ) ? 'found' : 'not found';
									*/
									
								if(isset($_POST['search']) && $_POST['search']!='')
								{
									$tmpArray=array();
									foreach($NewStudentArray as $key => $val)
									{
										
										
										if(substr_in_array($_POST['search'], $val ))
										{
											$tmpArray[]=$val;
										}
										else
										{
											
										}
									
									}
									
									
									$i=0;
									if(count($tmpArray)>0)
									{
										foreach($tmpArray as $key => $val)
										{
											$i++;
											if($tmpArray[$key]['certificateactivation']=='N')
												$status="Inactive";
											else
												$status="Active";
												
											$string.="<div class='search-classic'>";
											$string.="<br><br><b>".$i.") STUDENT NAME : </b>".$tmpArray[$key]['studentname'];
											$string.="<br><b>STUDENT ID : </b>".$tmpArray[$key]['studentid'];
											$string.="<br><b>COURSE NAME : </b>".$tmpArray[$key]['coursename'];
											$string.="<br><b>CERTIFICATION DATE : </b>".date("jS \of F Y",strtotime($tmpArray[$key]['certificatedate']))."</b>";
											$string.="<br><b>STATUS : </b>".$status;
											$string.="</div>";
										}
									}
									else
									{
										
										$string.="<div class='search-classic'>";
										$string.="<h4>No Record Match</h4>";
										$string.="</div>";
									}
								}
								?>
								<?php print $string;?>
								
								
								
							</div>
							<!--end tab-pane-->
							
							
						</div>
					</div>
				</div>
				<!--end tabbable-->
			</div>
			<!-- END PAGE CONTENT-->
		</div>
	</div>
	<!-- END CONTENT -->
	
</div>
<!-- END CONTAINER -->
<?php 
	require_once 'includes/adminFooter.php';
?>
<script src="../assets/admin/pages/scripts/studentapproval-editable.js"></script>
<script>
    jQuery(document).ready(function() {    
       Metronic.init(); // init metronic core components
Layout.init(); // init current layout
QuickSidebar.init() // init quick sidebar
TableEditable.init();
    });
  </script>
<!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>
	

