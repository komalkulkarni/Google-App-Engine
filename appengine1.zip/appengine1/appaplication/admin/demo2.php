<?php
require_once 'adminAuthorized.php';
require_once 'GoogleAppEngine/Google_Client.php';

$client=new Google_Client();
$credentials=new Google_AssertionCredentials($google_api_config['service-account-name'],
                                             array('https://www.googleapis.com/auth/userinfo.email',
                                                   'https://www.googleapis.com/auth/datastore'
                                                  ),
                                            $google_api_config['private-key']
                                            );
$client->setAssertionCredentials($credentials);

$postBody=json_encode(array('gqlQuery'=>array('allowLiteral'=>true, 'queryString'=>
          "SELECT * FROM StudentCertificate"
          )));
$httpRequest=new Google_HttpRequest('datastore/v1beta2/datasets/'.$google_api_config['dataset-id'].'/runQuery', 'POST', null, $postBody);
$head=array('content-type'=>'application/json; charset=UTF-8',
            'content-length'=>Google_Utils::getStrLen($postBody)
           );
$httpRequest->setRequestHeaders($head);
$httpRequest=Google_Client::$auth->sign($httpRequest);
$result=Google_REST::execute($httpRequest);
print "<pre>";var_export($result);print "</pre>";
?>

