<?php
	require_once 'adminAuthorized.php';
	require_once '../functions/commonFunctions.php';
	require_once '../classes/AgentModel.php';
	DatastoreService::setInstance(new DatastoreService($google_api_config));

	$agent_model = new AgentModel();
	
	
	if(isset($_POST['did']))
	{
		$agentInfofetched = AgentModel::fetch_by_name($_POST['did']);
		
		$objArr=array();
		foreach($agentInfofetched as $key => $val)
		{
			$objArr[]=$agent_model->getAgentEmail($val);
			
		}
		$agent_model = new AgentModel($objArr['0']['email'],$objArr['0']['password']);

		$agent_model->delete();
		
		print "Agent Deleted";
	}	
	
	elseif(isset($_POST['tid']))
	{
		$agentInfofetched = AgentModel::fetch_by_name($_POST['tid']);
		$objArr=array();
		foreach($agentInfofetched as $key => $val)
		{
			$objArr[]=$agent_model->getAgentEmail($val);
		}
		
		if($objArr['0']['agentactivation']=='Y')
			$agentActivation = 'N';
		else
			$agentActivation = 'Y';
		
		$agent_model = new AgentModel($objArr['0']['email'],$objArr['0']['password'],$agentActivation);

		$agent_model->put();
			
		print "Agent Edit.";
	}
	
	elseif(isset($_POST['eid']))
	{
		$repKey=str_replace('e--','',$_POST['key']);
		$agentInfofetched = AgentModel::fetch_by_name($repKey);
		$objArr=array();
		foreach($agentInfofetched as $key => $val)
		{
			$objArr[]=$agent_model->getAgentEmail($val);
		}
		
		
		$agent_modelDel = new AgentModel($objArr['0']['email'],$objArr['0']['password']);
		$agent_modelDel->delete();
			
		if($_POST['a']=='Active')
			$agentActivation = 'Y';
		else
			$agentActivation = 'N';
		
		$agent_model = new AgentModel($_POST['email'],$_POST['psw'],$agentActivation);
		$agent_model->put();
			
		print sha1($_POST['email'].$_POST['psw']);
	}
	
	elseif(isset($_POST['aid']))
	{
		
		if($_POST['a']=='Active')
			$agentActivation = 'Y';
		else
			$agentActivation = 'N';
		
		$agent_model = new AgentModel($_POST['email'],$_POST['psw'],$agentActivation);
		$agent_model->put();
		print sha1($_POST['email'].$_POST['psw']);
		//print "Agent Add Successfully.";
	}
?>