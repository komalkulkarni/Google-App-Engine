<?php
	require_once 'adminAuthorized.php';
	require_once '../functions/commonFunctions.php';
	$msg="";
	$objArr=array();
		
	require_once '../classes/StudentAgentModel.php';
	require_once '../classes/AgentModel.php';
										
	DatastoreService::setInstance(new DatastoreService($google_api_config));

	
	$course_model_fetched = StudentAgentModel::all();
	
	
	$StudentAgentDetails = new StudentAgentModel();
	
	if(isset($_GET['filterStatus']) && ($_GET['filterStatus']=='Y' || $_GET['filterStatus']=='N'))
	{
		foreach($course_model_fetched as $key => $val)
		{
			$objArr[]=$StudentAgentDetails->getCourseByFilter($val,$_GET['filterStatus']);
		}	
		
	}
	else
	{
		foreach($course_model_fetched as $key => $val)
		{
			$objArr[]=$StudentAgentDetails->getCourseEmail($val);
		}
	}
	$objArr=array_filter($objArr);
	$agent_model = new AgentModel();
	
?>
<!DOCTYPE html>

<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en" >
<!--<![endif]-->

<!-- BEGIN BODY -->
<!-- DOC: Apply "page-header-fixed-mobile" and "page-footer-fixed-mobile" class to body element to force fixed header or footer in mobile devices -->
<!-- DOC: Apply "page-sidebar-closed" class to the body and "page-sidebar-menu-closed" class to the sidebar menu element to hide the sidebar by default -->
<!-- DOC: Apply "page-sidebar-hide" class to the body to make the sidebar completely hidden on toggle -->
<!-- DOC: Apply "page-sidebar-closed-hide-logo" class to the body element to make the logo hidden on sidebar toggle -->
<!-- DOC: Apply "page-sidebar-hide" class to body element to completely hide the sidebar on sidebar toggle -->
<!-- DOC: Apply "page-sidebar-fixed" class to have fixed sidebar -->
<!-- DOC: Apply "page-footer-fixed" class to the body element to have fixed footer -->
<!-- DOC: Apply "page-sidebar-reversed" class to put the sidebar on the right side -->
<!-- DOC: Apply "page-full-width" class to the body element to have full width page without the sidebar menu -->
<body class="page-header-fixed page-quick-sidebar-over-content page-sidebar-closed-hide-logo">
	<?php 
		require_once 'includes/adminHeader.php';
	?>
<!-- BEGIN CONTAINER -->
<div class="page-container">
	<?php 
		require_once 'includes/adminLeftMenu.php';
	?>
	<!-- BEGIN CONTENT -->
	<div class="page-content-wrapper">
		<div class="page-content">
			
			<!-- BEGIN PAGE HEADER-->
			<div class="row">
				<div class="col-md-12">
					<!-- BEGIN PAGE TITLE & BREADCRUMB-->
					<h3 class="page-title">Welcome Admin User!</h3>
					<?php if($msg!=''){ print "<h3>".$msg."</h3>";}?>
					
					<!-- BEGIN EXAMPLE TABLE PORTLET-->
					<div class="portlet box blue">
						<div class="portlet-title">
							<div class="caption">
								<i class="fa fa-edit"></i>Approve Student Certificate
							</div>
							
							<div class="tools">
								<a href="javascript:;" class="collapse">
								</a>
								<a href="#portlet-config" data-toggle="modal" class="config">
								</a>
								<a href="javascript:;" class="reload">
								</a>
								<a href="javascript:;" class="remove">
								</a>
							</div>
						</div>
						<div class="portlet-body">
							<div class="table-toolbar">
								<!--<div class="btn-group">
									<button id="sample_editable_1_new" class="btn green">
									Add New <i class="fa fa-plus"></i>
									</button>
								</div>-->
								<div class="btn-group pull-right">
									<button class="btn dropdown-toggle" data-toggle="dropdown">Tools <i class="fa fa-angle-down"></i>
									</button>
									<ul class="dropdown-menu pull-right">
										<li>
											<a href="approveCertificationXml.php">
											Download Xml </a>
										</li>
										<li>
											<a href="?filterStatus=Y">
											Active </a>
										</li>
										<li>
											<a href="?filterStatus=N">
											Inactive </a>
										</li>
										<li>
											<a href="?filterStatus=YN">
											Both Active Inactive </a>
										</li>
										
									</ul>
								</div>
							</div>
							
							
							<table class="table table-striped table-hover table-bordered" id="sample_editable_1">
							<thead>
							<tr>
								<th>Course Name</th>
								<th>Agent Name</th>
								<th>Student Name</th>
								<th>Student Id</th>
								<th>Certification date</th>
								<th>
									 Active / Suspend
								</th>
								<th>
									 Edit
								</th>
								<th>
									 Delete
								</th>
							</tr>
							</thead>
							<tbody>
								<?php 
								foreach($objArr as $key => $val)
								{
									$agentObjArr=array();
									$searchAgentKey=$val['agentid'];
									
									$agentDetails = AgentModel::fetch_by_name($searchAgentKey);
									
									foreach($agentDetails as $key1 => $val1)
									{
										$agentObjArr[]=$agent_model->getAgentEmail($val1);
									}
								?>
									
										<tr id="p<?php echo $val['datakey']; ?>" >
											<td><span id="<?php print $val['coursename'];?>"><?php print $val['coursename'];?></span></td>
											<td><span id="<?php echo $agentObjArr['0']['datakey']; ?>"><?php print $agentObjArr['0']['email'];?></span></td>
											<td><?php print $val['studentname'];?></td>
											<td><?php print $val['studentid'];?></td>
											<td><?php print $val['certificatedate'];?></td>
											<td id="c<?php echo $val['datakey']; ?>"><?php if($val['certificateactivation']=='Y') print "<a onclick=\"activeDeactive('".$val['datakey']."','N')\">Suspend</a>";else print "<a onclick=\"activeDeactive('".$val['datakey']."','Y')\">Activate</a>";?></td>
												
											<td id="e--<?php echo $val['datakey']; ?>" >
												<a class="edit" href="javascript:;">
												Edit </a>
											</td>
											<td id="<?php echo $val['datakey']; ?>">
												<a class="delete" href="#">
												Delete </a>
											</td>
										</tr>
								<?php
								}
								?>
							
							</tbody>
							</table>
						</div>
					</div>
					<!-- END EXAMPLE TABLE PORTLET-->
				</div>
			</div>
			<!-- END PAGE HEADER-->
			
		</div>
	</div>
	<!-- END CONTENT -->
	
</div>
<!-- END CONTAINER -->

<?php 
	require_once 'includes/adminFooter.php';
?>
<script src="../assets/admin/pages/scripts/studentapproval-editable.js"></script>
<script>
    jQuery(document).ready(function() {    
       Metronic.init(); // init metronic core components
Layout.init(); // init current layout
QuickSidebar.init() // init quick sidebar
TableEditable.init();
    });
  </script>
<!-- END JAVASCRIPTS -->
</body>
<!-- END BODY -->
</html>
	<script type="text/javascript">
		function activeDeactive(key,value)
		{
			
			var id = key;
			var pid = 'p'+key;
			var cid = 'c'+key;
			var dataString = 'tid='+ id ;
			var parent = $(this).parent();
				
			$.ajax({
			   type: "POST",
			   url: "ajaxActiveCertificate.php",
			   data: dataString,
			   cache: false,

			   success: function()
			   {
					if(value=='Y')
						$('#'+cid).html("<a onclick=\"activeDeactive('"+key+"','N')\">Suspend</a>");
					else
						$('#'+cid).html("<a onclick=\"activeDeactive('"+key+"','Y')\">Activate</a>");
			   }
			   
			 });

			return false;
		}
		
		function deleteFunc(key)
		{
			var id = key;
			var dataString = 'did='+ id ;
				
			$.ajax({
			   type: "POST",
			   url: "ajaxActiveCertificate.php",
			   data: dataString,
			   cache: false,

			   success: function()
			   {
					
			   }
			   
			 });

			return false;
		
		}
		
		function addFunc(coursename,studentname,certificatedate,studentid,certificateactivation,agentid,k)
		{
			
			if(k=='' || k==undefined)
			{
				return false;
			}
			else	
			{
				
				var dataString = {coursename: coursename,studentname: studentname,certificatedate: certificatedate,studentid: studentid,certificateactivation: certificateactivation,agentid: agentid,key: k, eid:'edit'};	
				$.ajax({
				   type: "POST",
				   url: "ajaxActiveCertificate.php",
				   data: dataString,
				   cache: false,

				   success: function(data)
				   {
						var textTitle = k;
						
						var result = textTitle.replace('e--', '');
						
						var cid = 'c'+result;
						
						if(certificateactivation=='Active')
							$('#'+cid).html("<a onclick=\"activeDeactive('"+data+"','N')\">Suspend</a>");
						else
							$('#'+cid).html("<a onclick=\"activeDeactive('"+data+"','Y')\">Activate</a>");
							
						var cid1 = 'c'+result;
						var pid1 = 'p'+result;
						var ehashid1 = k;
						var normalid1 = result;

						$('#'+cid1 ).attr( "id", 'c'+data);
						$('#'+pid1 ).attr( "id", 'p'+data);
						$('#'+ehashid1 ).attr( "id", 'e--'+data);
						$('#'+normalid1 ).attr( "id", data);
				   }
				   
				 });

				return false;
				
			}
			
		}
	</script>

	
