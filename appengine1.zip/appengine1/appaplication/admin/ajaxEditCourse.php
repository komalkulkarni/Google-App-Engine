<?php
	require_once 'adminAuthorized.php';
	require_once '../functions/commonFunctions.php';
	require_once '../classes/CourseModel.php';
	require_once '../classes/StudentAgentModel.php';
	DatastoreService::setInstance(new DatastoreService($google_api_config));

	$course_model = new CourseModel();
	
	if(isset($_REQUEST['eid']))
	{
		$repKey=str_replace('e--','',$_POST['key']);
		$AllStudentObjArr=array();
		$fetchAllStudent = StudentAgentModel::all();
		$StudentAgentDetails = new StudentAgentModel();
		foreach($fetchAllStudent as $key => $val)
		{
			$AllStudentObjArr[]=$StudentAgentDetails->getEditCourseName($val,$repKey);
		}
		$NewStudentArray=array_filter($AllStudentObjArr);

		//edit
		$courseInfofetched = CourseModel::fetch_by_name($repKey);
		$objArr=array();
		foreach($courseInfofetched as $key1 => $val1)
		{
			$objArr[]=$course_model->getCourseEmail($val1);
		}
		
		$course_modelDel = new CourseModel($objArr['0']['coursename']);
		$course_modelDel->delete();
		
		
		$courseName = htmlspecialchars($_POST['coursename']);
		$courseDescription = htmlspecialchars($_POST['coursedescription']);
		$courseActivation = 'Y';	
		
		$course_model = new CourseModel($courseName,$courseDescription,$courseActivation);
		$course_model->put();
		print sha1($courseName);
		
		foreach($NewStudentArray as $key2 => $val2)
		{
			
		
			
			$courseidOld = $NewStudentArray[$key2]['courseid'];
			$coursenameOld = $NewStudentArray[$key2]['coursename'];
			$studentname = $NewStudentArray[$key2]['studentname'];
			$certificatedate = $NewStudentArray[$key2]['certificatedate'];
			$studentid = $NewStudentArray[$key2]['studentid'];
			$certificateactivation = $NewStudentArray[$key2]['certificateactivation'];
			$agentid = $NewStudentArray[$key2]['agentid'];
			$certificateadddate =  $NewStudentArray[$key2]['certificateadddate'];
			
			$stude_modelDel = new StudentAgentModel($courseidOld,$coursenameOld,$studentname,$certificatedate,$studentid,$certificateactivation,$agentid,$certificateadddate);
			$stude_modelDel->delete();
			
			$studentagent_model = new StudentAgentModel(sha1($courseName),$courseName,$studentname,$certificatedate,$studentid,$certificateactivation,$agentid,$certificateadddate);
			$studentagent_model->put();
		}
		
	
		
	}
?>