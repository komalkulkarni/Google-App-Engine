<?php
	session_start();
	require_once '../settings/config.php';
	require_once "../functions/commonFunctions.php";
	$msg="";
    if (array_key_exists_r('email|password|submit', $_POST)) 
	{
		require_once '../classes/UserModel.php';
		DatastoreService::setInstance(new DatastoreService($google_api_config));

		$email = $_POST['email'];
		$pname = $_POST['password'];
		
		$searchKey=sha1($email.$pname);
		
		$user_model = new UserModel($email,$pname);
		//$user_model->put();
		$user_model_fetched = UserModel::fetch_by_name($searchKey);
		
		
		if(count($user_model_fetched)>0)
		{
			$_SESSION['adminAuth']=$searchKey;
			header('Location: adminDashboard.php');   
		}
		else
		{
			$msg="Invalid Login";
		}

    }
	
	
    ?>

<html>
  <head>
	<link type="text/css" rel="stylesheet" href="../stylesheets/styles.css" />
	</head>
  <body>
   
	<div class="register-form">
		<?php if($msg!=''){ print "<h3>".$msg."</h3>";}?>
		<h1>Admin Login</h1>
		<form action="" method="post">
			<p>
				<label>User Name : </label>
				<input id="email" type="email" name="email" placeholder="Email" required />
			</p>	  
			<p>
				<label>Password&nbsp;&nbsp; : </label>
				<input id="password" type="password" name="password" placeholder="Password" required />
			</p>	  
				
			<input class="btn register" type="submit" name="submit" value="Login" />
		</form>
	</div>
  </body>
</html>