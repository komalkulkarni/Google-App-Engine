<?php
	require_once 'adminAuthorized.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<title>Welcome Admin User</title>
		<link href="../stylesheets/adminCommonCss1.css" rel="stylesheet" type="text/css" media="screen" />
	</head>
	
	<body>
		<?php 
			require_once 'includes/adminHeader.php';
		?>
		<div id="wrapper">
			<!-- start page -->
			<div id="page">
			<div id="page-bgtop">
			<div id="page-bgbtm">
				<?php 
					require_once 'includes/adminLeftMenu.php';
				?>
				<!-- start content -->
				<div id="content">
					<div class="flower"></div>
					<div class="post">
						<h1 class="title"><a href="#">Welcome Admin User!</a></h1>
						
					</div>
					
				</div>
				<!-- end content -->
				<?php 
					require_once 'includes/adminSideBar.php';
				?>
				<div style="clear: both;">&nbsp;</div>
			</div>
			</div>
			</div>
			<!-- end page -->
		</div>
		<?php 
			require_once 'includes/adminFooter.php';
		?>
	</body>
</html>
