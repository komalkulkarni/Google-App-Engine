<?php
	session_start();
	if(!isset($_SESSION['adminAuth']))
		header('Location: login.php');
		
	require_once '../settings/config.php';
?>